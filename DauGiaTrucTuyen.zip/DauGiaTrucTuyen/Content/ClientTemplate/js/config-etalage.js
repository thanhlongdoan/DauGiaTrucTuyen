﻿jQuery(document).ready(function ($) {
    $('#etalage').etalage({
        thumb_image_width: 300,
        thumb_image_height: 400,
        source_image_width: 420,
        source_image_height: 650,
        show_hint: true
    });
});