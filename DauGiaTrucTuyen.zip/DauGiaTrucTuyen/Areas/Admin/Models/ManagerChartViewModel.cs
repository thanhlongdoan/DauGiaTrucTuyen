﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DauGiaTrucTuyen.Areas.Admin.Models
{
    public class ChartViewModel
    {
        public DateTime dateTime { get; set; }
    }
}